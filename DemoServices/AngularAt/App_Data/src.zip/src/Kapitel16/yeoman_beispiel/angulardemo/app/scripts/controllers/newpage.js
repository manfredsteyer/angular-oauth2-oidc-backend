'use strict';

/**
 * @ngdoc function
 * @name angulardemoApp.controller:NewpageCtrl
 * @description
 * # NewpageCtrl
 * Controller of the angulardemoApp
 */
angular.module('angulardemoApp')
  .controller('NewpageCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
