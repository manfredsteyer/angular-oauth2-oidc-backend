﻿module flugapp.fluege {

    var app = angular.module("flugapp.fluege");
    /*
    

    
    app.controller("FlugBuchenCtrl", function ($scope: any, $http: ng.IHttpService, baseUrl: string) {

        $scope.vm = new FlugBuchenVM($http, baseUrl);

    });
    

    
    interface FlugBuchenScope extends ng.IScope {
        vm: FlugBuchenVM;
    }

    app.controller("FlugBuchenCtrl", function ($scope: FlugBuchenScope, $http: ng.IHttpService, baseUrl: string) {

        $scope.vm = new FlugBuchenVM($http, baseUrl);

    });
    
    */

    /*
    class FlugBuchenCtrl {

        constructor($scope: any, $http: ng.IHttpService, baseUrl: string) {
            $scope.vm = new FlugBuchenVM($http, baseUrl);
        }
    }

    app.controller("FlugBuchenCtrl", FlugBuchenCtrl);
    */

    app.controller("FlugBuchenVM", FlugBuchenVM);
}