var flugapp;
(function (flugapp) {
    var fluege;
    (function (fluege) {
        var FlugSuchenVM = (function () {
            function FlugSuchenVM($http) {
                this.selectedFlug = null;
                this.$http = $http;
            }
            FlugSuchenVM.prototype.loadFluege = function () {
                var that = this;
                var params = {
                    von: that.flugVonFilter,
                    nach: that.flugNachFilter
                };
                this.$http.get("http://www.angular.at/api/Flug", { params: params }).then(function (result) {
                    that.fluege = result.data;
                });
            };
            FlugSuchenVM.prototype.selectFlug = function (f) {
                this.selectedFlug = f;
            };
            return FlugSuchenVM;
        })();
        fluege.FlugSuchenVM = FlugSuchenVM;
    })(fluege = flugapp.fluege || (flugapp.fluege = {}));
})(flugapp || (flugapp = {}));
//# sourceMappingURL=FlugBuchenVM.mini.js.map