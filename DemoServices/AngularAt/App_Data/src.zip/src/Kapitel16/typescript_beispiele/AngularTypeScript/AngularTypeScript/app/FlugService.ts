﻿module flugapp.fluege {

    var app = angular.module("flugapp.fluege");

    export class FlugService {

        public constructor(private $http: ng.IHttpService, private baseUrl: string) {
        }

        public byRoute(abflugort: string, zielort: string): ng.IHttpPromise<Array<IFlug>> {
            var params = {
                abflugOrt: abflugort,
                zielOrt: zielort
            };

            return this.$http.get<Array<IFlug>>(this.baseUrl + "/api/flug", { params: params });
        }

    }

    //app.service("flugService", FlugService);

    //app.factory("flugService", function ($http: ng.IHttpService, baseUrl: string) {
    //    return new FlugService($http, baseUrl);
    //});

    export class FlugServiceProvider implements ng.IServiceProvider {

        public baseUrl: string;

        public $get($http: ng.IHttpService, baseUrl: string): FlugService {
            var baseUrlToUse = this.baseUrl || baseUrl;
            return new FlugService($http, baseUrlToUse);
        }
    }
    
    //app.provider("flugService", FlugServiceProvider);
    
    //app.provider("flugService", new FlugServiceProvider());
    
    app.provider("flugService", function () {
        return new FlugServiceProvider();
    });
    
    
    
    //app.provider("x"
} 