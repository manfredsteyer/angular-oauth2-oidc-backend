﻿module flugapp.fluege {

  
    export class FlugSuchenVM {

        private $http: ng.IHttpService;

        public constructor($http: ng.IHttpService) {
            this.$http = $http;
        }

        public fluege: Array<IFlug>;

        public selectedFlug: IFlug = null;

        public message: string;

            public flugVonFilter: string;
            public flugNachFilter: string;

            public loadFluege() {

                var that = this;

                var params = {
                    von: that.flugVonFilter,
                    nach: that.flugNachFilter
                }

                this.$http
                    .get<IFlug[]>("http://localhost:60604/api/Flug", { params: params })
                    .then(function (result) {

                    that.fluege = result.data;

                });
            }

            public selectFlug(f) {
                this.selectedFlug = f;
            }

        }


    }

