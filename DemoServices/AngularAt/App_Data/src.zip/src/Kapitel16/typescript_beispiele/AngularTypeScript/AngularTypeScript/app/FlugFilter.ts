﻿module flugapp.fluege {

    var app = angular.module("flugapp.fluege");

    app.filter("flugNr", function () {

        return function (value: number, format: string) {

            if (format == 'short') return String(value);

            switch (value) {
                case 1: return "LH4711";
                case 2: return "LH4712";
                case 3: return "LH4713";
                default: return String(value);
            }
        }

    });

}