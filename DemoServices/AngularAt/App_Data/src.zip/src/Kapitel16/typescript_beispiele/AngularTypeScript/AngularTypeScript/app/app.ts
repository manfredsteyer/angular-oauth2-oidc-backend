﻿module flugapp.fluege {

    var app = angular.module("flugapp.fluege", []);

    app.constant("baseUrl", "http://www.angular.at");

    app.config(function (flugServiceProvider: FlugServiceProvider) {

        flugServiceProvider.baseUrl = "http://www.angular.at/";

    });

}