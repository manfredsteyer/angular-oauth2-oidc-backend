﻿module flugapp.fluege {

    var app = angular.module("flugapp.fluege");

    interface IFlugDirectiveScope extends ng.IScope {
        flug: IFlug;
        info: string;
    }
   
    function createFlugInfoDirective(): ng.IDirective {
        return {
            scope: {
                "flug": "="
            },
            template: "{{info}}",
            controller: function ($scope: IFlugDirectiveScope) {

                var calcInfo = function () {
                    var info = "Flug #" + $scope.flug.id
                        + " von " + $scope.flug.abflugort
                        + " nach " + $scope.flug.zielort;

                    $scope.info = info;
                }

                calcInfo();

                $scope.$watchGroup(["flug.id", "flug.abflugort", "flug.zielort"], calcInfo);
            }

        };
    }

    app.directive("flugInfo", createFlugInfoDirective);

}

