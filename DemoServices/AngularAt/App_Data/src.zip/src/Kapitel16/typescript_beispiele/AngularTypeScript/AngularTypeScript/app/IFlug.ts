﻿module flugapp.fluege {

    export interface IFlug {
        id: number;
        abflugort: string;
        zielort: string;
        datum: string;
    }

}