﻿module flugapp.fluege {

   /* 
    export class FlugBuchenVM {

        public constructor(private $http:ng.IHttpService, private baseUrl: string) {
        }

        public fluege: Array<IFlug>;

        public selectedFlug: IFlug
        public message: string;

        public flugNummerFilter: string;
        public flugVonFilter: string;
        public flugNachFilter: string;

        public loadFluege() {

            var that = this;

            var params = {
                abflugOrt: that.flugVonFilter,
                zielOrt: that.flugNachFilter
            };

            that.$http
                .get<Array<IFlug>>(that.baseUrl + "/api/flug", { params: params })
                .then(function (result) {

                    // result: ng.IHttpPromiseCallbackArg<Array<IFlug>>
                    that.fluege = result.data;

                }).catch(function (result) {
                    that.message = "Fehler: " + result.status + " " + result.statusText + ", " + result.data.message;
                });
        }

        public selectFlug(f) {
            this.selectedFlug = f;
        }

    }
    */

    export class FlugBuchenVM {

        public constructor(private $http: ng.IHttpService, private flugService: FlugService, private baseUrl: string) {
        }

        public fluege: Array<IFlug>;

        public selectedFlug: IFlug = null;

        public message: string;

            public flugNummerFilter: string;
            public flugVonFilter: string;
            public flugNachFilter: string;

            public loadFluege() {

                var that = this;

                this.flugService.byRoute(that.flugVonFilter, that.flugNachFilter)
                    .then(function (result) {

                        // result: ng.IHttpPromiseCallbackArg<Array<IFlug>>
                        that.fluege = result.data;

                    }).catch(function (result) {
                        that.message = "Fehler: " + result.status + " " + result.statusText + ", " + result.data.message;
                    });
            }

            public selectFlug(f) {
                this.selectedFlug = f;
            }

        }


    }

