﻿var flugapp;
(function (flugapp) {
    (function (fluege) {
        var app = angular.module("flugapp.fluege");

        var FlugService = (function () {
            function FlugService($http, baseUrl) {
                this.$http = $http;
                this.baseUrl = baseUrl;
            }
            FlugService.prototype.byRoute = function (abflugort, zielort) {
                var params = {
                    abflugOrt: abflugort,
                    zielOrt: zielort
                };

                return this.$http.get(this.baseUrl + "/api/flug", { params: params });
            };
            return FlugService;
        })();
        fluege.FlugService = FlugService;

        //app.service("flugService", FlugService);
        //app.factory("flugService", function ($http: ng.IHttpService, baseUrl: string) {
        //    return new FlugService($http, baseUrl);
        //});
        var FlugServiceProvider = (function () {
            function FlugServiceProvider() {
            }
            FlugServiceProvider.prototype.$get = function ($http, baseUrl) {
                var baseUrlToUse = this.baseUrl || baseUrl;
                return new FlugService($http, baseUrlToUse);
            };
            return FlugServiceProvider;
        })();
        fluege.FlugServiceProvider = FlugServiceProvider;

        //app.provider("flugService", FlugServiceProvider);
        //app.provider("flugService", new FlugServiceProvider());
        app.provider("flugService", function () {
            return new FlugServiceProvider();
        });
    })(flugapp.fluege || (flugapp.fluege = {}));
    var fluege = flugapp.fluege;
})(flugapp || (flugapp = {}));
//# sourceMappingURL=FlugService.js.map
