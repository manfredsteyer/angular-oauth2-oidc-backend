﻿var flugapp;
(function (flugapp) {
    (function (fluege) {
        /*
        export class FlugBuchenVM {
        
        public constructor(private $http:ng.IHttpService, private baseUrl: string) {
        }
        
        public fluege: Array<IFlug>;
        
        public selectedFlug: IFlug
        public message: string;
        
        public flugNummerFilter: string;
        public flugVonFilter: string;
        public flugNachFilter: string;
        
        public loadFluege() {
        
        var that = this;
        
        var params = {
        abflugOrt: that.flugVonFilter,
        zielOrt: that.flugNachFilter
        };
        
        that.$http
        .get<Array<IFlug>>(that.baseUrl + "/api/flug", { params: params })
        .then(function (result) {
        
        // result: ng.IHttpPromiseCallbackArg<Array<IFlug>>
        that.fluege = result.data;
        
        }).catch(function (result) {
        that.message = "Fehler: " + result.status + " " + result.statusText + ", " + result.data.message;
        });
        }
        
        public selectFlug(f) {
        this.selectedFlug = f;
        }
        
        }
        */
        var FlugBuchenVM = (function () {
            function FlugBuchenVM($http, flugService, baseUrl) {
                this.$http = $http;
                this.flugService = flugService;
                this.baseUrl = baseUrl;
                this.selectedFlug = null;
            }
            FlugBuchenVM.prototype.loadFluege = function () {
                var that = this;

                this.flugService.byRoute(that.flugVonFilter, that.flugNachFilter).then(function (result) {
                    // result: ng.IHttpPromiseCallbackArg<Array<IFlug>>
                    that.fluege = result.data;
                }).catch(function (result) {
                    that.message = "Fehler: " + result.status + " " + result.statusText + ", " + result.data.message;
                });
            };

            FlugBuchenVM.prototype.selectFlug = function (f) {
                this.selectedFlug = f;
            };
            return FlugBuchenVM;
        })();
        fluege.FlugBuchenVM = FlugBuchenVM;
    })(flugapp.fluege || (flugapp.fluege = {}));
    var fluege = flugapp.fluege;
})(flugapp || (flugapp = {}));
//# sourceMappingURL=FlugBuchenVM.js.map
