var flugapp;
(function (flugapp) {
    var fluege;
    (function (fluege) {
        var app = angular.module("flugapp.fluege");
        function createFlugInfoDirective() {
            return {
                scope: {
                    "flug": "="
                },
                template: "{{info}}",
                controller: function ($scope) {
                    var calcInfo = function () {
                        var info = "Flug #" + $scope.flug.id + " von " + $scope.flug.abflugort + " nach " + $scope.flug.zielort;
                        $scope.info = info;
                    };
                    calcInfo();
                    $scope.$watchGroup(["flug.id", "flug.abflugort", "flug.zielort"], calcInfo);
                }
            };
        }
        app.directive("flugInfo", createFlugInfoDirective);
    })(fluege = flugapp.fluege || (flugapp.fluege = {}));
})(flugapp || (flugapp = {}));
//# sourceMappingURL=FlugDirektive.js.map