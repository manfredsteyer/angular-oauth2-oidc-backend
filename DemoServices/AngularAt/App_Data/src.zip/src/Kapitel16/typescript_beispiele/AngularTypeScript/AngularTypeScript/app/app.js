﻿var flugapp;
(function (flugapp) {
    (function (fluege) {
        var app = angular.module("flugapp.fluege", []);

        app.constant("baseUrl", "http://www.angular.at");

        app.config(function (flugServiceProvider) {
            flugServiceProvider.baseUrl = "http://www.angular.at/";
        });
    })(flugapp.fluege || (flugapp.fluege = {}));
    var fluege = flugapp.fluege;
})(flugapp || (flugapp = {}));
//# sourceMappingURL=app.js.map
