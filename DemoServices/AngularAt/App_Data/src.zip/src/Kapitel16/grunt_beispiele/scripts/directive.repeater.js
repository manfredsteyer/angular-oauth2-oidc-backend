app.directive('repeater', function() {
  return {
    restrict: 'E',
    scope: {},
    template: '<ul><li ng-repeat="item in components">{{item}}</li></ul>',
    link: function(scope, element, attrs) {
      scope.components = [
        'AngularJS', 'Bootstrap', 'jQuery', 'Grunt', 'Bower'
      ]
    }
  }
})
