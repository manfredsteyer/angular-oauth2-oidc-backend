app.controller('MainCtrl', function($scope, Hello) {
  $scope.service = Hello;
});
