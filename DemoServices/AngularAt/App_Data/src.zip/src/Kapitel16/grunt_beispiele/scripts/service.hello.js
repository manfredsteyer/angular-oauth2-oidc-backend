app.factory('Hello', function() {
  return {
    greeting: 'Hallo AngularJS, Bower und Grunt'
  };
});
