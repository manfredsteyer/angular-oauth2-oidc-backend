module.exports = function(grunt) {

    grunt.initConfig({
        injector: {
            options: {},
            bower_dependencies: {
                options: {
                    bowerPrefix: 'bower:'
                },
                files: {
                    'index.html': ['bower.json'],
                }
            },
            local_dependencies: {
                files: {
                    'index.html': ['scripts/*.js', 'css/*.css'],
                }
            }
        },
        serve: {
            options: {
                port: 9000
            }
        }
    });


    grunt.loadNpmTasks('grunt-injector');
    grunt.loadNpmTasks('grunt-serve');

    // Default task(s).
    grunt.registerTask('default', ['injector', 'serve']);
};
