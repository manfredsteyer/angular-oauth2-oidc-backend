angular
    .module("flug", ["flug.buchen", "components.common.filters"])
    .constant("baseUrl", "http://www.angular.at")
    .config(function($logProvider) { 
        $logProvider.debugEnabled(true);
    })
    .run(function($log) { 
            $log.debug("function app.run called");
            $log.info("app started ...");
    });