angular
    .module("components.common.filters")
    .filter("flugNr", function() { 

        return function(value, format) {

            if (format == 'short') return value;
            
            switch(value) {
                case 1: return "LH4711";
                case 2: return "LH4712";
                case 3: return "LH4713";
                default: value;    
            }
        }
    });
