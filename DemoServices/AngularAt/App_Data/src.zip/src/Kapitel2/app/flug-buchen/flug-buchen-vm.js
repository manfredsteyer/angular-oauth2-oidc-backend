function FlugBuchenVM($http, baseUrl) {
    var that = this;

    this.fluege = new Array();

    this.selectedFlug = null;
    this.message = "";

    this.flugNummerFilter = "";
    this.flugVonFilter = "";
    this.flugNachFilter = "";

    this.flugVonClientFilter = "";
    this.flugNachClientFilter = "";

    this.sortColumn = "id";
    this.sortDirection = false;

    this.setSortColumn = function(colName) {

        if (this.sortColumn == colName) {
            this.sortDirection = !this.sortDirection;   
        }
        else {
            this.sortColumn = colName;  
            this.sortDirection = false;
        }
    }

    this.comparator = function(actual, expected) {
        if (!expected) return true;
        if (actual.length < expected.length) return false;
        return actual.substr(0, expected.length) == expected; 
    }



    this.customFilterFunc = function(value, index) { 
        return value.abflugort == 'Graz' || value.abflugort == 'Frankfurt' 
    }



    this.loadFluege = function () {

        var params = {};

        if (that.flugNummerFilter) {
            params = {
                flugNummer: that.flugNummerFilter
            };
        } else {
            params = {
                abflugOrt: that.flugVonFilter,
                zielOrt: that.flugNachFilter
            };
        }

    $http
        .get(baseUrl + "/api/flug", { params: params })
        .then(function (result) {

            if (angular.isArray(result.data)) {
                that.fluege = result.data;
            }
            else {
                that.fluege = [result.data];
            }


        }).catch(function (result) {
            that.message = "Fehler: " + result.status + " " + result.statusText + ", " + result.data.message;
        });

    }

    this.sortFunc = function(obj) {
        return obj.datum.getTime() * -1;
    }



    this.selectFlug = function (f) {
        this.selectedFlug = f;
    };

}
