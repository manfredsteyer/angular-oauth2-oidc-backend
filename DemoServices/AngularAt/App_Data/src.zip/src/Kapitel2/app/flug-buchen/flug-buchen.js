angular
    .module("flug.buchen", []);

