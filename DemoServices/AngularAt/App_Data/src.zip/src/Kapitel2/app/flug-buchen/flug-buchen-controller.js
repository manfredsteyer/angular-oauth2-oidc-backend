angular
    .module("flug.buchen")
    .controller("FlugBuchenCtrl", function ($scope, $http, baseUrl) {
        $scope.vm = new FlugBuchenVM($http, baseUrl);
    });