var langSwitcher = angular.module("lang.switcher", []);
langSwitcher.controller("LangSwitcherCtrl", function($scope, $rootScope) { 

    $scope.model = {};

    $scope.model.setLang = function(lang) {
        $scope.model.lang = lang;
        $rootScope.$broadcast("lang.switcher:language-set", $scope.model.lang);
    }
});