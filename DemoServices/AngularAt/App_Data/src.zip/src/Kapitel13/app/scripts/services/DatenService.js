//-----------------------------------------------------------------------------------
// Schritt 1: Value Service
//-----------------------------------------------------------------------------------
//angular.module('kapitel15ServicesApp').value('DatenService', ['Test1', 'Test2', 'Test3']);


//-----------------------------------------------------------------------------------
// Schritt 2: Factory
//-----------------------------------------------------------------------------------
angular.module('kapitel15ServicesApp').factory('DatenService', function($http) {
  var backendDaten = null;

  var datenLaden = function() {
    $http.get('PFAD/ZU/UNSEREM/BACKEND').success(function(daten) {
      backendDaten = daten;
    });
  };

  datenLaden();

  return {
    getDaten: function() {
      return backendDaten;
    },
    neuesElement: function(elem) {
      backendDaten.push(elem);
    }
  };
});


//-----------------------------------------------------------------------------------
// Schritt 3: Service
//-----------------------------------------------------------------------------------
/*var UpperCaseFormatter = function() {};
UpperCaseFormatter.prototype.format = function(val) {
  return val + " :-) ";
};

var DatenServiceClass = function($http) {
  var self = this;
  self.backendDaten = null;

  $http.get('PFAD/ZU/UNSEREM/BACKEND').success(function(daten) {
    self.backendDaten = daten;
  });
};

DatenServiceClass.prototype = new UpperCaseFormatter();
DatenServiceClass.prototype.constructor = DatenServiceClass;

DatenServiceClass.prototype.getDaten = function() {
  return this.backendDaten;
};

DatenServiceClass.prototype.neuesElement = function(elem) {
  this.backendDaten.push(elem);
};


angular.module('kapitel15ServicesApp').service('DatenService', DatenServiceClass);
*/
