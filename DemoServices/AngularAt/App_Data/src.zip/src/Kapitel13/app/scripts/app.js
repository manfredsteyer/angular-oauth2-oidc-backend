'use strict';

/**
 * @ngdoc overview
 * @name kapitel15ServicesApp
 * @description
 * # kapitel15ServicesApp
 *
 * Main module of the application.
 */
angular
  .module('kapitel15ServicesApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'ngMockE2E'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/demo.html',
        controller: 'ListenCtrl'
      })
      .when('/decorator', {
        templateUrl: 'views/decorator.html',
        controller: 'DecoratorCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  })
  .run(function($httpBackend) {


    // Passthrough with default routeProvider routes
    $httpBackend.whenGET('views/demo.html').passThrough();
    $httpBackend.whenGET('views/decorator.html').passThrough();
    $httpBackend.whenGET('PFAD/ZU/UNSEREM/BACKEND').respond([ 'Backend Fake1', 'Backend Fake2', 'Backend Fake3' ]);

    // do real request
    $httpBackend.whenJSONP().passThrough();
  })
  .controller('ShellCtrl', function ($scope, $location, $route) {
    $scope.isActivePage = function(page) {
      return $location.path() === page;
    };
  });
