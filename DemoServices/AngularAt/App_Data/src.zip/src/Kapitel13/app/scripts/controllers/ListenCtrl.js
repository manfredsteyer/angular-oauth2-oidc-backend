//-----------------------------------------------------------------------------------
// Schritt 1: Value Service
//-----------------------------------------------------------------------------------
/*angular.module('kapitel15ServicesApp')
  .controller("ListenCtrl", function($scope, DatenService) {
    $scope.listenDaten = DatenService;

    $scope.neuesElement = function(elem) {
      DatenService.push(elem);
    };
  });*/


//-----------------------------------------------------------------------------------
// Schritt 2: Factory
//-----------------------------------------------------------------------------------
angular.module('kapitel15ServicesApp').controller("ListenCtrl", function($scope, DatenService) {
  $scope.service = DatenService;

  $scope.neuesElement = function(elem) {
    $scope.service.neuesElement(elem);
  };
});


//-----------------------------------------------------------------------------------
// Schritt 3: Service
//-----------------------------------------------------------------------------------
/*angular.module('kapitel15ServicesApp').controller("ListenCtrl", function($scope, DatenService) {
  $scope.service = DatenService;

  $scope.neuesElement = function(elem) {
    $scope.service.neuesElement($scope.formattiereAusgabe(elem));
  };

  $scope.formattiereAusgabe = function(elem) {
    return DatenService.format(elem);
  };
});*/
