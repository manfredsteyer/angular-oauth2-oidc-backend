// Direktive
angular.module('kapitel15ServicesApp')
  .directive('hello', function() {
    return {
      restrict: 'A',
      replace: true,
      template: '<p>Hallo AngularJS</p>'
    };
  });
