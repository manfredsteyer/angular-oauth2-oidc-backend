angular.module('kapitel15ServicesApp')
  .controller("DecoratorCtrl", function($scope) {
    $scope.price = 12.77;
  });
