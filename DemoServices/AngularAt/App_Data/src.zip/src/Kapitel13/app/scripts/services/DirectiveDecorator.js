'use strict';

angular.module('kapitel15ServicesApp')
  .config(function($provide) {
    $provide.decorator('DatenService', function($delegate) {
      var origFn = $delegate.getDaten;

      $delegate.getDaten = function() {
        console.log('Vom Decorator erweitert');
        return origFn();
      };

      return $delegate;
    });
  })

  .config(function($provide) {
    $provide.decorator('helloDirective', function($delegate) {
      console.log($delegate);
      var directive = $delegate[0];
      var counter = 0;

      directive.restrict = 'EA';
      directive.compile = function() {
        return function(scope, element, attrs) {
          console.log('Hello Direktive ' + (++counter) + ' mal ausgeführt!');
        };
      };

      return $delegate;
    });
  })

  .config(function($provide) {
    $provide.decorator('$locale', function($delegate) {
      $delegate.NUMBER_FORMATS.CURRENCY_SYM = 'EUR';
      return $delegate;
    });
  });
