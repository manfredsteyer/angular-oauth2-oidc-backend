Zum Ausf�hren des Beispiels sind folgende Schritte notwendig:

* mit einer Konsole in den wechseln
* npm install
* bower install
* grunt serve