var app = angular.module('AngularUIBootstrapDemo', ['ui.bootstrap']);

app.controller('MainCtrl', function($scope) {
  // Schaltflächen
  $scope.selectedFramework = '';

  // Datum
  $scope.selectedDate = new Date();
  $scope.isCalendarOpen = false;
  $scope.calendarFormat = 'dd.MM.yyyy';
  $scope.toggleCalendar = function($event) {
    $event.preventDefault();
    $event.stopPropagation();

    $scope.isCalendarOpen = !$scope.isCalendarOpen;
  };

  // Pagination
  $scope.currentNews = 2;
  $scope.totalItems = function() { return $scope.paginatedNews.length; };
  $scope.paginatedNews = [
    'News 1', 'News 2','News 3','News 4','News 5',
    'News 6','News 7','News 8','News 9','News 10',
    'News 11','News 12','News 13','News 14','News 15',
    'News 16','News 17','News 18','News 19','News 20',
    'News 21','News 22','News 23' ,'News 24'
  ];
  $scope.getItemsFromCurrentPage = function() {
    var start = ($scope.currentNews-1) * 5,
          end = $scope.currentNews * 5;

    return $scope.paginatedNews.slice(start, end);
  };
});
