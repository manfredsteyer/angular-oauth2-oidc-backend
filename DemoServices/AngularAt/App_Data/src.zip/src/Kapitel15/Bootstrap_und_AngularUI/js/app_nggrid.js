var app = angular.module('AngularUINGGrid', ['ngGrid']);

app.controller('MainCtrl', function($scope) {
  $scope.books = [
    {
      name: 'AngularJS: Up and Running',
      authors: 'Shyam Seshadri, Brad Green',
      pages: 302,
      topic: 'AngularJS'
    },
    {
      name: 'Learning AngularJS',
      authors: 'Ken Williamson',
      pages: 200,
      topic: 'AngularJS'
    },
    {
      name: 'AngularJS',
      authors: 'Manfred Steyer, Softic Vildan',
      pages: 304,
      topic: 'AngularJS'
    },
    {
      name: 'JavaScript: The Good Parts',
      authors: 'Douglas Crockford',
      pages: 172,
      topic: 'JavaScript'
    },
    {
      name: 'Functional JavaScript',
      authors: 'Michael Fogus',
      pages: 260,
      topic: 'JavaScript'
    },
    {
      name: 'Learning JavaScript Design Patterns',
      authors: 'Addy Osmani',
      pages: 254,
      topic: 'JavaScript'
    }
  ];

  // Einfaches Basis-Grid
  $scope.basicGridOptions = { data: 'books' };

  // Spaltenkonfigurationen
  $scope.columnConfigGridOptions = {
    data: 'books',
    columnDefs: [
      {field: 'name', displayName: 'Buchtitel', width:270},
      {field: 'authors', displayName: 'Autoren', width:220},
      {field: 'pages', displayName: 'Seiten #'},
      {field: 'topic', displayName: 'Thema', visible: false}
    ],
    sortInfo: { fields: ['name'], directions: ['asc'] }
  };

  // Editierbares Grid
  $scope.modifiedRow;
  $scope.changeType;

  $scope.editGridOptions = {
    data: 'books',
    columnDefs: [
      {field: 'name', displayName: 'Buchtitel', width:270},
      {field: 'authors', displayName: 'Autoren', width:220},
      {field: 'pages', displayName: 'Seiten #'},
      {field: 'topic', displayName: 'Thema', enableCellEdit: false}
    ],
    enableCellSelection: true,
    enableRowSelection: false,
    enableCellEdit: true
  };

  $scope.$on('ngGridEventStartCellEdit', function (e) {
    var editedRow = e.targetScope.row.entity;
    console.log('Zelle wurde in Editiermodus versetzt ...');

    $scope.$apply(function() {
      $scope.modifiedRow = editedRow;
      $scope.changeType = "wird";
    });
  });

  $scope.$on('ngGridEventEndCellEdit', function (e) {
    var changedRow = e.targetScope.row.entity;
    console.log('Daten per Ajax an Server senden ...');

    $scope.$apply(function() {
      $scope.modifiedRow = changedRow;
      $scope.changeType = "wurde";
    });
  });

  // Zusätzliche Features
  $scope.additionalFeaturesGridOptions = {
    data: 'books',
    columnDefs: [
      {field: 'name', displayName: 'Buchtitel', width:270},
      {field: 'authors', displayName: 'Autoren', width:220},
      {field: 'pages', displayName: 'Seiten #', width: 100},
      {field: 'topic', displayName: 'Thema', width: 100}
    ],
    showGroupPanel: true,
    enablePinning: true
  };
});
