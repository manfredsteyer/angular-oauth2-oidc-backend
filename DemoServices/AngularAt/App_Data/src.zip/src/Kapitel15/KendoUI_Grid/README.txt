1. Node installieren
2. Mit terminal/node cmd in backend Ordner wechseln
3. npm install (Node Abh�ngigkeiten f�r das Backend installieren)
4. node index.js (starten des Backends, default port = 8080)

5. neues terminal/node cmd aufmachen und in frontend Ordner wechseln
6. npm install (Node Abh�ngigkeiten f�r das Frontend installieren)
7. bower install (Bower Abh�ngigkeiten installieren)
8. grunt serve (erstellt HTTP Webserver und �ffnet automatisch ein Browserfenster mit LiveReload)
