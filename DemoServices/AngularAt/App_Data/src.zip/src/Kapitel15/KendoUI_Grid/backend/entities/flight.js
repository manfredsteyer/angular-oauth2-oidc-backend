
var FlightEntity = function(name, departure, destination, startTime, endTime, passengersCount) {
  var self = this;

  //Auto-generated self._id;
  self.name = name;
  self.departure = departure;
  self.destination = destination;
  self.startTime = startTime;
  self.endTime = endTime;
  self.passengersCount = passengersCount;
};

module.exports = FlightEntity;
