var restify = require('restify'),
    flightEntity = require('./entities/flight'),
    dataStore = require('nedb');

var server = restify.createServer({
  name: 'AngularDemoBackend'
});
server.use(restify.bodyParser());
server.use(
  function crossOrigin(req,res,next){
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    return next();
  }
);

var flightDB = new dataStore();
flightDB.insert([
  new flightEntity("MH1002", "Frankfurt", "Hamburg", "06:00", "07:45", 98),
  new flightEntity("LH107", "Frankfurt", "Wien", "08:30", "10:00", 48),
  new flightEntity("OS 980", "Graz", "Wien", "11:00", "11:30", 10),
  new flightEntity("LJ 928", "Graz", "Frankfurt", "17:30", "20:00", 55)
]);

server.listen(8080, function() {
  console.log('%s listening at %s', server.name, server.url);
});

server.get('/kendogrid', function getAllFlights(req, res, next) {
  flightDB.find({}, function(err, docs) {
    res.setHeader('content-type', 'application/json');
    res.send(200, docs);
  });
});

server.put('/kendogrid/:id', function updateFlight(req, res, next) {
  flightDB.update({ _id: req.params._id}, req.params, {}, function(err, numReplaced, newDoc) {
    res.setHeader('content-type', 'application/json');
    res.send(200, req.params);
  });
});

server.del('/kendogrid/:id', function deleteFlight(req, res, next) {
  flightDB.remove({ _id: req.params._id });

  res.send();
});

server.post('/kendogrid', function addFlight(req, res, next) {
  flightDB.insert(req.params, function(err, newDoc) {
    res.setHeader('content-type', 'application/json');
    res.send(200, newDoc);
  });
});
