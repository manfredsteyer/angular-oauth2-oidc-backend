'use strict';

/**
 * @ngdoc function
 * @name demoApp.controller:KendoGridCtrl
 * @description
 * # KendoGridCtrl
 * Controller for KendoUI Grid Demo
 */
angular.module('demoApp')
  .controller('KendoGridCtrl', function ($scope, kendoGridDataSource) {
    
    $scope.flightDate = new Date();
    $scope.kendoGridVM = kendoGridDataSource;

  });
