/*global kendo*/
'use strict';

angular.module('demoApp')
       .factory('kendoGridDataSource',
    function ()
    {
      // Der Endpunkt unseres REST-Services
      var serviceURL = 'http://localhost:8080/kendogrid';

      return {
        // Deklaration des Datenzugriffs
        dataSource: new kendo.data.DataSource({
          // NodeJS + Restify übertragen JSON
          type: 'json',
          // Beschreibung der Datenübertragung
          transport: {
            // Lesen von Flügen
            // GET: /kendogrid
            read: {
              // Grid erst nach geladenen Daten aufbauen
              async: false,
              // Standard REST -> GET ohne Parameter
              url: serviceURL,
              dataType: 'json'
            },
            // Update eines Fluges
            // PUT: /kendogrid
            update: {
              // URL auch als Funktion definierbar
              url: function (data)
              {
                return serviceURL + '/' + data._id;
              },
              // erzwinge PUT für Updates
              type: 'PUT',
              dataType: 'json'
            },
            // Löschen eines Fluges
            // DELETE: /kendogrid/:id
            destroy: {
              url: function (data)
              {
                  return serviceURL + '/' + data._id;
                },
              type: 'delete',
              dataType: 'json'
            },
            // Anlegen eines neuen Fluges
            // POST: /kendogrid
            create: {
              url: serviceURL,
              type: 'post',
              dataType: 'json'
            }
          },
          batch: false,
          // Clientseitiges Features aktivieren
          serverPaging: false,
          serverSorting: false,
          serverFiltering: false,
          pageSize: 10,
          // Model Beschreibung
          schema: {
            model: {
              // Primärer Identifikator eines Fluges
              id: '_id',
              fields: {
                // ID kann nicht verändert werden
                _id: { editable: false, nullable: true},
                name: { validation: { required: true } },
                departure: { validation: { required: true } },
                destination: { validation: { required: true } },
                startTime: { validation: { required: true } },
                endTime: { validation: { required: true } },
                passengersCount: { type: 'number', validation: { min: 5, required: true } }
              }
            }
          }
        }),
        gridOptions: {
          // Features aktivieren
          sortable: true,
          selectable: true,
          groupable: true,
          filterable: {
            mode: 'row'
          },
          // Änderungen direkt im Grid vornehmen
          editable: 'inline',
          // Hinzufügen Button über Grid
          toolbar: [
            { name: 'create', text: 'Neuen Flug anlegen' }
          ],
          // Definition der Sichtbaren spalten
          columns: [
            // Entity property + Spaltenname
            { field: 'name', title: 'Flugname' },
            { field: 'departure', title: 'Abflugort' },
            { field: 'destination', title: 'Ankunftsort' },
            { field: 'startTime', title: 'Abflugszeit' },
            { field: 'endTime', title: 'Ankunftszeit' },
            { field: 'passengersCount', title: 'Passagiere #' },
            // CRUD Operationen pro Zeile
            {
              command: [
                { name: 'edit', text: 'Editieren' },
                { name: 'destroy', text: 'Löschen' }
              ],
              title: '&nbsp;',
              width: 220
            }
          ]
        }
      };
    });
