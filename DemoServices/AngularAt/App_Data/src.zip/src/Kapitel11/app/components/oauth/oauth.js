﻿(function () { 

    angular.module("oauth2", []);

})();