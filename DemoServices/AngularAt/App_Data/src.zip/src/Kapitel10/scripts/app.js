'use strict';

define(['angular', 'ngResource', 'ngRoute'], function(ng) {
  return ng.module('frontendApp', [
    'ngResource',
    'ngRoute'
  ]);
});

