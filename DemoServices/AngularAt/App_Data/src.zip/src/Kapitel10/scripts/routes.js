'use strict';

define(['app', 'controllers/product_overview'], function(app) {
  app.config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/product_overview.html',
        controller: 'ProductOverviewCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
});
