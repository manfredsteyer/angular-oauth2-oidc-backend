define(function(require) {

  var Product = function(name, price, vat, type) {
    this.name = name;
    this.price = price;
    this.vat = vat;
    this.type = type;
  };

  Product.prototype.getTotalPrice = function() {
    return this.price * ((100 + this.vat)/100);
  };

  return Product;
});
