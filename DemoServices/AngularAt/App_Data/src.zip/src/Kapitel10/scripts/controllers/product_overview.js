'use strict';

define(['app', 'services/product_service', 'directives/cart_widget'], function(app) {
  return app.controller('ProductOverviewCtrl', function ($scope, ProductService) {
    $scope.service = ProductService;
  });
});
