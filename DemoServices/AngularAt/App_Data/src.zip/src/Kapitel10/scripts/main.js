'use strict';

require.config({

  paths: {
    'angular': '../bower_components/angular/angular.min',
    'ngResource': '../bower_components/angular-resource/angular-resource.min',
    'ngRoute': '../bower_components/angular-route/angular-route.min',
    '_': '../bower_components/lodash/dist/lodash.min'
  },

  shim: {
    'angular': {
      exports: 'angular'
    },
    'ngResource': {
      deps: ['angular']
    },
    'ngRoute': {
      deps: ['angular']
    }
  },
});

// Bootstrap the Application
define(['angular', 'app', 'routes'], function(ng) {
  ng.element(document).ready(function() {
    ng.bootstrap(document, ['frontendApp']);
  });
});
