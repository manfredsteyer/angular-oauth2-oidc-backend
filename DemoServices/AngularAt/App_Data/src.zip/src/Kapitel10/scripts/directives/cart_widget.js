'use strict';

define(function(require) {
  var app = require('app');

  app.directive('cartWidget', function () {

    return {
      templateUrl: '/templates/cart_widget.html',
      restrict: 'E',
      replace: true,
      scope: {
        service: '=service'
      }
    };

  });
});
