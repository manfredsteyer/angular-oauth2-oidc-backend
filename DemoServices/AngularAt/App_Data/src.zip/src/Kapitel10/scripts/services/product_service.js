'use strict';

define(function(require) {
  var app = require('app');

  return app.factory('ProductService', function() {

    var Product = require('entities/product_entity'),
      _ = require('_'),
      products = [
        new Product('NG Cola', 1.2, 10, 'Getränk'),
        new Product('NGO Saft', 0.8, 10, 'Getränk'),
        new Product('Turbo NG', 1.6, 10, 'Hustenbonbon'),
        new Product('NG Tischlein', 55.0, 20, 'Möbel'),
        new Product('NGINX', 0.0, 0, 'WebServer'),
        new Product('aNGular', 0.0, 0, 'Frontend Framework'),
        new Product('NorweGium', 0.0, 0, 'Chemisches Symbol (Ng)'),
      ],
      cartItems = [];

    return {
      products: products,
      cartItems: cartItems,
      addProductToCart: function(product) {
        if(!_.any(cartItems, function(p) { return p.name === product.name; })) {
          cartItems.push(product);
        }
      },
      removeProductFromCart: function(product) {
        cartItems.splice(cartItems.indexOf(product), 1);
      },
      getCountOfProductsInCart: function() {
        return cartItems.length;
      }
    };
  });
});
