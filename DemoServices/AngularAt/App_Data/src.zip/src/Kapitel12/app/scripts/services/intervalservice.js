'use strict';

/**
 * @ngdoc service
 * @name angulardemoApp.Intervalservice
 * @description
 * # Intervalservice
 * Service in the angulardemoApp.
 */
// Service
angular.module('angulardemoApp')
  .service('Intervalservice', function Intervalservice($interval) {
    var color1 = 'transparent',
        color2 = 'red',
        self = this;


    self.currentColor = color1;

    $interval(function() {
      self.currentColor = (self.currentColor === color1) ? color2 : color1;
    }, 100);
  });
