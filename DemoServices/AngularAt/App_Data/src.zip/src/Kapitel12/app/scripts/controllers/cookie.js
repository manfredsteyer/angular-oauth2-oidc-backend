'use strict';

/**
 * @ngdoc function
 * @name angulardemoApp.controller:CookieCtrl
 * @description
 * # MainCtrl
 * Controller of the angulardemoApp
 */
angular.module('angulardemoApp')
  .controller('CookieCtrl', function ($scope, $cookies, CartService) {
    $scope.service = CartService;
    CartService.init();
    CartService.addProduct({id: 2, name: 'TEST' });
  });
