angular.module('angulardemoApp').
  directive('blink', ['$interval' , function($interval) {
    return {
      restrict: 'E',
      link: function(scope, element, attrs){
        var intervalPromise,
            pause = attrs.pause || 500,
            color1 = attrs.color1 || "transparent",
            color2 = attrs.color2 || "red",
            currentColor = color1,
            count = attrs.count || 6;


        intervalPromise = $interval(function() {
          currentColor = (currentColor === color1) ? color2 : color1;
          element.css({
            backgroundColor: currentColor
          });
        }, pause, count);

        element.on('$destroy', function() {
          $interval.cancel(intervalPromise);
          alert('Element zerstört, Interval beendet.');
        });
      }
    }
  }]);
