angular.module('angulardemoApp')
  .service('CartService', ['$cookieStore', function($cookieStore) {

    return {
      addProduct: function(product) {
        var customerProducts = $cookieStore.get('customerProducts');
        // --> { products: [ { id: 1, name: 'Product 1'}, ... ]}

        customerProducts.products.push(product);
        // --> { products: [ { id: 1, name: 'Product 1'}, ..., { id: X, name: 'Product NEW'} ]}

        $cookieStore.put('customerProducts', customerProducts);
      },
      clearCart: function() {
        $cookieStore.remove('customerProducts');
      },
      init: function() {
        this.clearCart();
        $cookieStore.put('customerProducts', { products: [ { id: 1, name: 'Product 1'}]});
      },
      data: $cookieStore.get('customerProducts')
    };
  }]);
