'use strict';

/**
 * @ngdoc overview
 * @name angulardemoApp
 * @description
 * # angulardemoApp
 *
 * Main module of the application.
 */
angular
  .module('angulardemoApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])

  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/drag.html',
        controller: 'DragCtrl'
      })
      .when('/cookie', {
        templateUrl: 'views/cookie.html',
        controller: 'CookieCtrl'
      })
      .when('/scroll', {
        templateUrl: 'views/scroll.html',
        controller: 'ScrollCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  })

  .controller('ShellCtrl', function ($scope, $location, $route) {
    $scope.isActivePage = function(page) {
      return $location.path() === page;
    };
  });
