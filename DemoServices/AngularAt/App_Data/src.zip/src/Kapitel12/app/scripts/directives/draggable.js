angular.module('angulardemoApp').
  directive('draggable', ['$document' , function($document) {
    return {
      restrict: 'A',
      link: function(scope, element, attrs) {
        var elemInitialX,
            elemInitialY,
            mouseX,
            mouseY;


        element.css({
          position: 'absolute',
          cursor: 'pointer',
          top: attrs.draggableTop,
          left: attrs.draggableLeft
        });

        element.bind('mousedown', function($event) {
          elemInitialX = element.prop('offsetLeft');
          elemInitialY = element.prop('offsetTop');
          mouseX = $event.clientX;
          mouseY = $event.clientY;

          $document.bind('mousemove', onMouseMove);
          $document.bind('mouseup', onMouseUp);

          return false;
        });

        function onMouseMove($event) {
          element.css({
            top:  elemInitialY + ($event.clientY - mouseY) + 'px',
            left: elemInitialX + ($event.clientX - mouseX) + 'px'
          });

          return false;
        }

        function onMouseUp() {
          $document.unbind('mousemove', onMouseMove);
          $document.unbind('mouseup', onMouseUp);
        }
      }
    };
  }]);
