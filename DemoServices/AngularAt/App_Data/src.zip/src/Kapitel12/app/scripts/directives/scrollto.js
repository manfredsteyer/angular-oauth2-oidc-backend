angular.module('angulardemoApp').
  directive('scrollTo', ['$window' , function($window) {
    return {
      link: function(scope, element, attrs) {
        element.click(function() {
          var destination = $('a[href="#' + attrs.scrollTo + '"]'),
              posTop = destination[0].offsetTop,
              adjustment = 10;

          $window.scrollTo(0, posTop - adjustment);
        });
      }
    };
  }]);
