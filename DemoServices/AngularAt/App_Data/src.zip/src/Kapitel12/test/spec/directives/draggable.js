describe('draggable directive', function() {
  var $rootScope,
      $scope,
      $compile,
      el,
      $body = $('body'),
      testHTML = '<p class="well col-xs-2" draggable  draggable-left="650px"  draggable-top="400px">Element 2</p>';

  beforeEach(function() {
    module('angulardemoApp');

    inject(function($injector) {
      $rootScope = $injector.get('$rootScope');
      $scope = $rootScope.$new();

      $compile = $injector.get('$compile');
      el = $compile(angular.element(testHTML))($scope);
    });
  });

  it('should set position absolute to element', function() {
    expect(el.css('position')).toBe('absolute');
  });

  it('should set top and left according to attrs', function() {
    expect(el.css('left')).toBe('650px');
    expect(el.css('top')).toBe('400px');
  });
});
