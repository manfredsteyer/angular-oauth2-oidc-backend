'use strict';

describe('Controller: CookieCtrl', function () {

  // load the controller's module
  beforeEach(module('angulardemoApp'));

  var CookieCtrl,
    scope,
    mockService = {
      init: function() {
        return true;
      },
      addProduct: function() {
        return true;
      }
    };


  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    scope.service = mockService;

    CookieCtrl = $controller('CookieCtrl', {
      $scope: scope
    });
  }));

  it('should have a CartService', inject(function ($controller) {
    expect(scope.service).toBeDefined();
  }));

  it('should start init of service', inject(function ($controller) {
    spyOn(mockService, 'init');

    CookieCtrl = $controller('CookieCtrl', {
      $scope: scope,
      CartService: mockService
    });

    expect(mockService.init).toHaveBeenCalled();
  }));
});
