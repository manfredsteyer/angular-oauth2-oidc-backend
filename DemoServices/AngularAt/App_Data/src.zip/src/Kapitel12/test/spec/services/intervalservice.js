// Unit Test
describe('Service: Intervalservice', function () {
  it('should alternate colors on ticks', function () {
      var service, $interval;
      module('angulardemoApp');

      inject(function (Intervalservice, _$interval_) {
          // Initialize the service under test instance
          service = Intervalservice;
          $interval = _$interval_;
      });

      expect(service.currentColor).toEqual('transparent');
      $interval.flush(101);
      expect(service.currentColor).toEqual('red');
      $interval.flush(100);
      expect(service.currentColor).toEqual('transparent');
  });
});
