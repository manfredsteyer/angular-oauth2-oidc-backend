describe('blink directive', function () {

    var $rootScope,
        $scope,
        $compile,
        el,
        $body = $('body'),
        testHTML = '<blink color-1="transparent" color-2="red" pause="500" count="8">Lorem ipsum dolor sit amet</blink>';

    beforeEach(function() {
        inject(function($injector) {
          $rootScope = $injector.get('$rootScope');
          $scope = $rootScope.$new();

          $compile = $injector.get('$compile');
          el = $compile(angular.element(testHTML))($scope);
        });
    });

    it('should change color on tick', function(done) {
        $scope.$digest();
    });
});
