'use strict';

// Code für Service
angular.module('TestModule', []).service('DelayedService', function($timeout) {
  var executed = false,
      timeoutPromise;

  timeoutPromise = $timeout(function() {
    executed = true;
  }, 2000);

  this.isExecuted = function() {
    return executed;
  };
});

// Unit Test
describe('timeout service', function() {
  it('set executed to true after timeout', function () {
      var service, $timeout;
      module('TestModule');

      inject(function (DelayedService, _$timeout_) {
          // Initialize the service under test instance
          service = DelayedService;
          $timeout = _$timeout_;
      });

      expect(service.isExecuted()).toBe(false);
      $timeout.flush(1000);
      expect(service.isExecuted()).toBe(false);
      $timeout.flush(1001);
      expect(service.isExecuted()).toBe(true);
  });
});
