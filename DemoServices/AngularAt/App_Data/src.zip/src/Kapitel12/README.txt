Zum Ausf�hren des Beispiels sind folgende Schritte notwendig:

* mit einer Konsole in den wechseln
* npm install
* bower install
* grunt serve

Um die Unit tests auszuf�hren:

* mit einer Konsole in den Unterordner test wechseln
* karma start eingeben